package com.coconutcoders.zendaya.zendayaBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZendayaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
